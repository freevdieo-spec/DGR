## Character Concepts
Use for early ideas.